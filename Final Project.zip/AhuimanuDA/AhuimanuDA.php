1 <?php 
2 /* 
3 Plugin Name: Ahuimanu Darksky Weather 
4 Plugin URI: http://github.com/ahuimanu/AhuimanuDarkSkyWeather 
5 Description: Reads the DarkSky REST API and Provides a shortcode and widget. Also does Google Reverse Goecoding. 
6 Version: 1.0 
7 Author: Jeffry Babb 
8 Author URI: http://github.com/ahuimanu/ 
9 Text Domain: ahuimanu-plugin 
10 License: GPLv3 
11  */ 
12  
13 register_activation_hook(__FILE__, 'ahuimanu_darksky_weather_install'); 
14  
15 function ahuimanu_darksky_weather_install(){ 
16     global $wp_version; 
17  
18     if( version_compare($wp_version, '4.1', '<')){ 
19 		wp_die('This plugin requires WordPress Version 4.1 or higher.'); 
20 	} 
21 } 
22  
23 register_deactivation_hook(__FILE__, 'ahuimanu_darksky_weather_deactivate'); 
24  
25 function ahuimanu_darksky_weather_deactivate(){ 
26     //do something when deactivating 
27 } 
28  
29 /** 
30  * @param $apikey 
31  * @param $lat 
32  * @param $lon 
33  * 
34  * Constructs the Google Maps Geocoding URL 
35  * @return string 
36  */ 
37 function get_google_reverse_geocode_url($apikey, $lat, $lon){ 
38     //https://maps.googleapis.com/maps/api/geocode/json?latlng=40.714224,-73.961452&key=YOUR_API_KEY 
39     $google_url = 'https://maps.googleapis.com/maps/api/geocode/json?'; 
40     $google_url .= 'latlng=' . $lat . ',' . $lon; 
41     $google_url .= '&key=' . $apikey; 
42  
43     return $google_url; 
44 } 
45  
46 /** 
47  * @param $url 
48  * Gets JSON from the Google Reverse Geocode API 
49  * @return array|mixed|object|string 
50  */ 
51 function get_google_reverse_geocode_json($url){ 
52  
53 	$request = wp_remote_get( $url ); 
54  
55 	if( is_wp_error( $request ) ) { 
56 		return 'could not obtain data'; // Bail early 
57 	}else { 
58  
59 		//retreive message body from web service 
60 		$body = wp_remote_retrieve_body( $request ); 
61  
62 		//obtain JSON - as object or array 
63 		$data = json_decode( $body, true ); 
64  
65 		return $data; 
66 	} 
67 } 
68  
69 /** 
70  * @param $apikey 
71  * @param $lat 
72  * @param $lon 
73  * 
74  * Constructs the DarkSky API URL 
75  * 
76  * @return string 
77  */ 
78 function get_darksky_url($apikey, $lat, $lon){ 
79  
80 	//'https://api.darksky.net/forecast/ 
81 	$darksky_url = 'https://api.darksky.net/forecast/'; 
82 	$darksky_url .= $apikey . '/'; 
83 	$darksky_url .= $lat . ',' . $lon; 
84  
85 	return $darksky_url; 
86 } 
87  
88 /** 
89  * @param $url 
90  * Gets JSON from the DarkSky API 
91  * @return array|mixed|object|string 
92  */ 
93 function get_darksky_json($url){ 
94  
95 	$request = wp_remote_get( $url ); 
96  
97 	if( is_wp_error( $request ) ) { 
98 		return 'could not obtain data'; // Bail early 
99 	}else { 
100  
101 		//retreive message body from web service 
102 		$body = wp_remote_retrieve_body( $request ); 
103  
104 		//obtain JSON - as object or array 
105 		$data = json_decode( $body, true ); 
106  
107 		return $data; 
108 	} 
109 } 
110  
111 add_action( 'widgets_init', 'ahuimanu_darksky_weather_create_widgets' ); 
112  
113 function ahuimanu_darksky_weather_create_widgets() { 
114 	register_widget( 'Ahuimanu_DarkySky_Weather' ); 
115 } 
116  
117 class Ahuimanu_DarkySky_Weather extends WP_Widget { 
118 	// Construction function 
119 	function __construct () { 
120 		parent::__construct( 'Ahuimanu_DarkySky_Weather', 'DarkSky Weather', 
121 			array( 'description' => 
122 				       'Displays current weather from the DarkSky API' ) ); 
123 	} 
124  
125 	/** 
126 	 * @param array $instance 
127      * Code to show the administrative interface for the Widget 
128 	 */ 
129 	function form( $instance ) { 
130 		// Retrieve previous values from instance 
131 		// or set default values if not present 
132 		$darksky_api_key = ( !empty( $instance['darksky_api_key'] ) ? 
133 			esc_attr( $instance['darksky_api_key'] ) : 
134 			'error' ); 
135  
136 		$darksky_api_lat = ( !empty( $instance['darksky_api_lat'] ) ? 
137 			esc_attr( $instance['darksky_api_lat'] ) : 'error'); 
138  
139 		$darksky_api_lon = ( !empty( $instance['darksky_api_lon'] ) ? 
140 			esc_attr( $instance['darksky_api_lon'] ) : 
141 			'error' ); 
142  
143 		$google_maps_api_key = ( !empty( $instance['google_maps_api_key'] ) ? 
144 			esc_attr( $instance['google_maps_api_key'] ) : 
145 			'error' ); 
146  
147 		$widget_title = ( !empty( $instance['widget_title'] ) ? 
148 			esc_attr( $instance['widget_title'] ) : 
149 			'Dark Sky Weather' ); 
150  
151         ?> 
152         <!-- Display fields to specify title and item count --> 
153         <p> 
154             <label for="<?php echo 
155 			$this->get_field_id( 'widget_title' ); ?>"> 
156 				<?php echo 'Widget Title:'; ?> 
157                 <input type="text" 
158                        id="<?php echo 
159 				       $this->get_field_id( 'widget_title' );?>" 
160                        name="<?php 
161 				       echo $this->get_field_name( 'widget_title' ); ?>" 
162                        value="<?php echo $widget_title; ?>" /> 
163             </label> 
164         </p> 
165         <p> 
166             <label for="<?php echo 
167 			$this->get_field_id( 'darksky_api_key' ); ?>"> 
168 				<?php echo 'Darksky API Key:'; ?> 
169                 <input type="text" 
170                        id="<?php echo 
171 				       $this->get_field_id( 'darksky_api_key' );?>" 
172                        name="<?php 
173 				       echo $this->get_field_name( 'darksky_api_key' ); ?>" 
174                        value="<?php echo $darksky_api_key; ?>" /> 
175             </label> 
176         </p> 
177         <p> 
178             <label for="<?php echo 
179 			$this->get_field_id( 'darksky_api_lat' ); ?>"> 
180 				<?php echo 'Darksky API Latitude:'; ?> 
181                 <input type="text" 
182                        id="<?php echo 
183 				       $this->get_field_id( 'darksky_api_lat' );?>" 
184                        name="<?php 
185 				       echo $this->get_field_name( 'darksky_api_lat' ); ?>" 
186                        value="<?php echo $darksky_api_lat; ?>" /> 
187             </label> 
188         </p> 
189         <p> 
190             <label for="<?php echo 
191 			$this->get_field_id( 'darksky_api_lon' ); ?>"> 
192 				<?php echo 'Darksky API Longitude:'; ?> 
193                 <input type="text" 
194                        id="<?php echo 
195 				       $this->get_field_id( 'darksky_api_lon' );?>" 
196                        name="<?php 
197 				       echo $this->get_field_name( 'darksky_api_lon' ); ?>" 
198                        value="<?php echo $darksky_api_lon; ?>" /> 
199             </label> 
200         </p> 
201         <p> 
202             <label for="<?php echo 
203 			$this->get_field_id( 'google_maps_api_key' ); ?>"> 
204 				<?php echo 'Google Maps API Key:'; ?> 
205                 <input type="text" 
206                        id="<?php echo 
207 				       $this->get_field_id( 'google_maps_api_key' );?>" 
208                        name="<?php 
209 				       echo $this->get_field_name( 'google_maps_api_key' ); ?>" 
210                        value="<?php echo $google_maps_api_key; ?>" /> 
211             </label> 
212         </p> 
213         <script> 
214             jQuery(document).ready(function(){ 
215                 if(navigator.geolocation){ 
216                     navigator.geolocation.getCurrentPosition(showLocation); 
217                 }else{ 
218                     console.log('Geolocation is not supported by this browser.'); 
219                     jQuery('#location').html('Geolocation is not supported by this browser.'); 
220                 } 
221             }); 
222  
223             function showLocation(position){ 
224                 var latitude = position.coords.latitude; 
225  
226                 console.log("latitude: " + latitude); 
227  
228                 document.getElementById('<?php echo $this->get_field_id( 'darksky_api_lat' ); ?>') 
229                     .setAttribute('value', latitude); 
230  
231                 var longitude = position.coords.longitude; 
232  
233                 console.log("longitude: " + longitude); 
234  
235                 document.getElementById('<?php echo $this->get_field_id( 'darksky_api_lon' ); ?>') 
236                     .setAttribute('value', longitude); 
237  
238             } 
239         </script> 
240 
 
241 	<?php } 
242  
243 	/** 
244 	 * @param array $new_instance 
245 	 * @param array $instance 
246 	 * 
247      * Code to update the admin interface for the widget 
248      * 
249 	 * @return array 
250 	 */ 
251 	function update( $new_instance, $instance ) { 
252  
253 		$instance['widget_title'] = 
254 			sanitize_text_field( $new_instance['widget_title'] ); 
255  
256 		$instance['darksky_api_key'] = 
257 			sanitize_text_field( $new_instance['darksky_api_key'] ); 
258  
259 		$instance['darksky_api_lat'] = 
260 			sanitize_text_field( $new_instance['darksky_api_lat'] ); 
261  
262 		$instance['darksky_api_lon'] = 
263 			sanitize_text_field( $new_instance['darksky_api_lon'] ); 
264  
265 		$instance['google_maps_api_key'] = 
266 			sanitize_text_field( $new_instance['google_maps_api_key'] ); 
267  
268 		return $instance; 
269 	} 
270  
271 	/** 
272 	 * @param array $args 
273 	 * @param array $instance 
274      * 
275      * Code for the display of the widget 
276      * 
277 	 */ 
278 	function widget( $args, $instance ) { 
279  
280         // Extract members of args array as individual variables 
281         extract( $args ); 
282  
283         $widget_title = ( !empty( $instance['widget_title'] ) ? 
284             esc_attr( $instance['widget_title'] ) : 
285             'Dark Sky Weather' ); 
286  
287         $widget_darksky_api_key = ( !empty( $instance['darksky_api_key'] ) ? 
288 	        esc_attr( $instance['darksky_api_key'] ) : 
289 	        '0' ); 
290  
291 		$widget_lat = ( !empty( $instance['darksky_api_lat'] ) ? 
292 			esc_attr( $instance['darksky_api_lat'] ) : 
293 			'0' ); 
294  
295 		$widget_lon = ( !empty( $instance['darksky_api_lon'] ) ? 
296 			esc_attr( $instance['darksky_api_lon'] ) : 
297 			'0' ); 
298  
299 		$widget_google_maps_api_key = ( !empty( $instance['google_maps_api_key'] ) ? 
300 			esc_attr( $instance['google_maps_api_key'] ) : 
301 			'0' ); 
302  
303 		//get URLs 
304 		$url_darksky = get_darksky_url($widget_darksky_api_key, $widget_lat, $widget_lon); 
305 		$url_google = get_google_reverse_geocode_url($widget_google_maps_api_key, $widget_lat, $widget_lon); 
306  
307 		//obtain JSON - as object or array 
308 		$data_darksky = get_darksky_json($url_darksky); 
309 		$data_google = get_google_reverse_geocode_json($url_google); 
310  
311 		//$output .= print_r($data_darksky); 
312  
313         // Display widget title 
314         echo $before_widget . $before_title; 
315         echo apply_filters( 'widget_title', $widget_title ); 
316         echo $after_title; 
317  
318         //echo "Weather information for: " . $data_google['results'][0]['address_components']['long_name']; 
319 		echo "Weather information for: <br>"; 
320         echo $data_google['results'][0]['address_components'][2]['long_name'] . ", "; 
321 		echo $data_google['results'][0]['address_components'][3]['long_name'] . ", "; 
322 		echo $data_google['results'][0]['address_components'][4]['long_name'] . ", "; 
323 		echo $data_google['results'][0]['address_components'][5]['long_name']; 
324 		echo '<br>'; 
325         echo date("l jS \of F Y h:i:s A", intval($data_darksky['currently']['time'])) . " UTC"; 
326 		echo '<br>'; 
327 		//https://wordpress.stackexchange.com/questions/60230/how-to-call-images-from-your-plugins-image-folder 
328 		echo '<img src="' . plugin_dir_url( __FILE__ ) . 
329 		     'DarkSky-icons/PNG/' . $data_darksky['currently']['icon'] . '.png">'; 
330 		echo '<br>'; 
331         echo "latitude: " . $data_darksky['latitude']; 
332         echo '<br>'; 
333         echo "longitude: " . $data_darksky['longitude']; 
334 		echo '<br>'; 
335 		echo "Temperature: " . round($data_darksky['currently']['temperature']) . " �F"; 
336 		echo '<br>'; 
337 		echo "Dew Point: " . round($data_darksky['currently']['dewPoint']) . " �F"; 
338 		echo '<br>'; 
339 		echo "Humdity: " . (floatval($data_darksky['currently']['humidity']) * 100) . "%"; 
340 		echo '<br>'; 
341 		echo "Wind Direction: " . $data_darksky['currently']['windBearing'] . "�"; 
342 		echo '<br>'; 
343 		echo "Wind Speed: " . round($data_darksky['currently']['windSpeed']) . " mph"; 
344 		echo '<br>'; 
345 		echo "Pressure: " . round($data_darksky['currently']['pressure']) . " mb"; 
346 		echo '<br>'; 
347  
348         echo $after_widget; 
349 	} 
350 } 
351 ?> 